Tema poate fi rulata in urmatorul mod:

prima data se executa comanda in consola enrole. Deja sunt creati 2 utilizatori, andrei.dumitrascu@mta.ro si iulian.tita@mta.ro
Apoi se poate trimite primul mail cu comanda send si se completeaza campurile cerute
Pentru a vedea mailurile, se tasteaza read si se completeaza campurile afisate.

Exemplu:
	daca introducem comanda read, putem citi 2 mailuri deja introduse in fisierul ce tine secventele in format hexa:
	1. read
	2. iulian.tita@mta.ro
	3. index: 1 sau 2, doar 2 mailuri sunt deja scrise